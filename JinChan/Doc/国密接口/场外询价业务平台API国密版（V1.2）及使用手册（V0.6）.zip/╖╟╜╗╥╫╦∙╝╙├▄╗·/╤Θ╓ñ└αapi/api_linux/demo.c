#include <stdio.h>
#include <string.h>
#include "include/keyfld_enc.h"

void sge_safe_keyfld_enc_mgmt_test() {
    int ret = 0;
    char *in = "12345678901234567890123456789012";//注：参照《会员二级系统接入国密标准关键域加密规范--会员培训材料》6示例。in输入相当于Y
    char out[128] = {0};
    size_t out_len = 128;

    ret = sge_safe_keyfld_enc_mgmt(in, strlen(in), out, &out_len);
    printf("mgmt_test : ret = %d, out = [%s], out_len = %d\n", ret, out, out_len);

    return ;
}

void sge_safe_keyfld_enc_verification_test() {
    int ret = 0;
    char out[128] = {0};
    size_t out_len = 128;
    char *in = "12345678901234567890123456789012";//注：参照《会员二级系统接入国密标准关键域加密规范--会员培训材料》6示例。in输入相当于Y
    char *random = "01234567890123456789012345678912";//注：参照《会员二级系统接入国密标准关键域加密规范--会员培训材料》6示例。in输入相当于R
    
    ret = sge_safe_keyfld_enc_verification(in, strlen(in), random, strlen(random), out, &out_len);
    printf("verification_test: ret = %d, out = [%s], out_len = %d\n", ret, out, out_len);

}

int main(int argc, char **argv) {
    sge_safe_keyfld_enc_mgmt_test();
    sge_safe_keyfld_enc_verification_test(); 

}





