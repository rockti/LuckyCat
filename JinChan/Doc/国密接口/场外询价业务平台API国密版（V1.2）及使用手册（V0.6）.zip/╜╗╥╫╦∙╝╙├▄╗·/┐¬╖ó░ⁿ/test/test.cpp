/* ϵͳ */
#include <stdio.h>
#include <fcntl.h>
#include <memory.h>
#include <errno.h>
#include <sys/types.h>
#include <assert.h>
#include <locale.h>
#include <math.h>
#include <time.h>

#ifdef _WIN32
#include <windows.h>
#define DLLEXPORT __stdcall
#define STRNCPY		strncpy_s
#define SNPRINTF	_snprintf_s
#define SCANF	scanf_s
#define SLEEP(sec)	Sleep((sec)* 1000)
HINSTANCE DllHandle;
HINSTANCE SafeDllHandle;
#define loadfunction(hModule, lpProcName) \
	GetProcAddress(hModule, lpProcName)
#define freedll(hModule) \
	FreeLibrary(hModule)
#define geterror() \
	GetLastError()
#define  LIBRARY_FILE_NAME "GTPAPIGM.dll"
#define  SAFE_LIBRARY_FILE_NAME "sgesafe.dll"
#else
#include <dlfcn.h>
#include <string.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>
#include <pthread.h>
#define DLLEXPORT 
#define STRNCPY		strncpy
#define SNPRINTF	snprintf
#define SCANF	scanf
#define SLEEP(sec)	sleep(sec)
void* DllHandle;
void* SafeDllHandle;
#define loadfunction(handle,symbol) \
	dlsym(handle, symbol)

#define freedll(handle) \
	dlclose(handle)

#define geterror() \
	dlerror()
#define  LIBRARY_FILE_NAME "libGTPAPIGM.so"
#define  SAFE_LIBRARY_FILE_NAME "libsgesafe.so"
#endif

//����GTPAPIͷ�ļ�
#include "gtpApiGM.h"
#include "sgesafe.h"

int gtpLogin(char* traderid, char* accessid);
int traderLogin(char* traderid, char* accessid);
int regRecv(char* accessid);
int warehouseQuery(char* traderid, char* accessid);

//GTPAPIGM����
typedef int (*GTPEnvInitProc)(SAFE_FUNC* _safe_func);
typedef int(*GTPSetOptionProc)(char* key, char* value);
typedef  int(*GTPLoginProc)(char* ipList, char* portList, char* traderID, char* accessID, char* accessPasswd, BREAK_DATA_INFO* breakData);
typedef  int(*GTPMsgRecProc)(char* accessID, callBack pcallBack, callErrorBack pcallErrorBack, callUTCTimeBack pcallUTCTimeBack);
typedef int(*GTPMsgSendProc)(char* accessID, HEADER* header, char* msgBuffer, unsigned int* logID);
typedef int(*GTPLogoutProc)(char* accessID);
typedef int(*GTPEnvClearProc)();

GTPEnvInitProc pGTPEnvInit;
GTPSetOptionProc pGTPSetOption;
GTPLoginProc pGTPLogin;
GTPMsgRecProc pGTPMsgRec;
GTPMsgSendProc pGTPMsgSend;
GTPLogoutProc pGTPLogout;
GTPEnvClearProc pGTPEnvClear;

//sgesafe����
typedef int(*InitEnvProc)(char* sIp, int nPort);
typedef int(*ClearEnvProc)();
typedef int(*ConfirmSessionKeyProc)(char *pUserID, unsigned char  *pCipherKey, int nCipherKeyLen, unsigned char  *pSessionKey, int *pSessionKeyLen);
typedef int(*SignProc)(char *pUserID, unsigned char  *pOrgData, int nOrgDataSize, unsigned char  *pSignData, int* pSignDataSize);
typedef int(*VerifySignProc)(unsigned char *pPubKey, int nPubKeyLen, unsigned char  *pOrgData, int pOrgDataSize, unsigned char  *pSignData, int pSignDataSize);
typedef int(*GetPubKeyForSignProc)(char* pUserID, unsigned char *pPubKey, int* nPubKeyLen);
typedef int(*GetPubKeyProc)(char* pUserID, unsigned char *pPubKey, int* nPubKeyLen);
typedef int(*SM4EncryptProc)(unsigned char *pOrgData, int nOrgDataSize, unsigned char* key, unsigned char *pOutData, int* pOutDataSize);
typedef int(*SM4DecryptProc)(unsigned char *pOrgData, int nOrgDataSize, unsigned char* key, unsigned char *pOutData, int* pOutDataSize);
InitEnvProc pSafeInitEnv;
ClearEnvProc pSafeClearEnv;
ConfirmSessionKeyProc pSafeConfirmSessionKey;
SignProc pSafeSign;
VerifySignProc pSafeVerifySign;
GetPubKeyForSignProc pSafeGetPubKeyForSign;
GetPubKeyProc pSafeGetPubKey;
SM4EncryptProc pSafeSM4Encrypt;
SM4DecryptProc pSafeSM4Decrypt;

//char traderid[2][20] = { "pzh06074","pff1074"};
//char accessid[20] = "pzh06074";
//char seatid[20] = "007411";
char traderid[2][20] = { "pzp2003","pzw3003"};
char accessid[20] = "pzp2003";
char seatid[20] = "000311";

#ifdef _WIN32
DWORD WINAPI ThreadFun(LPVOID pM)
{
	traderLogin((char*)pM, accessid);
	SLEEP(5);
	warehouseQuery((char*)pM, accessid);
	return 0;
}
#else
void* ThreadFun(void* pM)
{
	traderLogin((char*)pM, accessid);
	SLEEP(5);
	warehouseQuery((char*)pM, accessid);
}
#endif

//������Ϣִ�еĻص�����
 int  DLLEXPORT printcallback(CALLBACK_MESSAGE *pcallback_message)
{
	printf("receive msg: seriesno[%s], seqid[%s],logid[%d], msgtype[%s], content: %s\n", \
		pcallback_message->header.csequenceSeriesNo, pcallback_message->header.csequenceNo , pcallback_message->ilogID
		,pcallback_message->header.cmsgType, pcallback_message->cpmessage);
	return 0;
}
//������Ϣִ�еĻص�����
 void DLLEXPORT  printcallErrorback(int code)
{
	printf("receive error[%d]\n", code);
	return ;
}
//���շ�����ʱ��
 void DLLEXPORT  printcallUTCTimeBack(int pcallHeartTimeBack)
{
	printf("UTC time[%d]\n", pcallHeartTimeBack);
	return ;
}

 //��ȫ�ص�����
 SAFE_FUNC safe_func;
 //�Ự��Կ
 unsigned char _sessionKey[200];

 int DLLEXPORT init()
 {
	 //��ʼ��
	 int ret = 0;
	 printf("callback safe_InitEnv\n");
	 ret = pSafeInitEnv("180.3.12.118",8889); //���ܻ�ip�˿�
	 printf("callback safe_InitEnv done:%d\n", ret);
	 return ret;
 }

 int DLLEXPORT clear()
 {
	 printf("callback safe_ClearEnv\n");
	 return pSafeClearEnv();
 }

 char* getuid(char* traderid)
 {
	 //���ܻ��еĻ���id
	 return "00031101";// "00741101";
 }

 int DLLEXPORT getpubkey(char* traderID, int type, unsigned char *pPubKey, int* nPubKeyLen)
 {
	 int ret = 0;
	 printf("callback safe_GetPubKey\n");
	 char* uid = getuid(traderID);
	 //ȡ��Կ
	 if (type == 0)
	 {
		 ret = pSafeGetPubKeyForSign(uid, pPubKey, nPubKeyLen);
	 }else
		ret = pSafeGetPubKey(uid, pPubKey, nPubKeyLen);
	 printf("callback safe_GetPubKey done:%d\n", ret);
	 return ret;
 }
 int DLLEXPORT confirmkey(char* traderID, unsigned char *pCipherKey, int nCipherKeyLen, unsigned char *pSessionKey, int *pSessionKeyLen)
 {
	 printf("callback safe_ConfirmSessionKey\n");
	 char* uid = getuid(traderID);
	 //���ջỰ��Կ
	 int ret = pSafeConfirmSessionKey(uid, pCipherKey, nCipherKeyLen, pSessionKey, pSessionKeyLen);
	 memset(_sessionKey, 0x00, 200);
	 memcpy(_sessionKey, pSessionKey, *pSessionKeyLen);
	 return ret;
 }
 int DLLEXPORT encrypt(char* traderID, unsigned char* pOrgData, int nOrgDataSize, unsigned char  *pSessionKey, unsigned char* pOutData, int *pOutDataSize)
 {
	 printf("callback safe_SM4Encrypt\n");
	 //SM4���� �Ự��Կ
	 return pSafeSM4Encrypt(pOrgData, nOrgDataSize, pSessionKey, pOutData, pOutDataSize);
 }
 int DLLEXPORT decrypt(char* traderID, unsigned char* pOrgData, int nOrgDataSize, unsigned char  *pSessionKey, unsigned char* pOutData, int *pOutDataSize)
 {
	 printf("callback safe_SM4Decrypt\n");
	 char* uid = getuid(traderID);
	 //SM4���� �Ự��Կ
	 return pSafeSM4Decrypt(pOrgData, nOrgDataSize, pSessionKey, pOutData, pOutDataSize);
 }
 int DLLEXPORT sign(char* traderID, unsigned char* pOrgData, int nOrgDataSize, unsigned char* pSignData, int* pSignDataSize)
 {
	 printf("callback safe_Sign\n");
	 char* uid = getuid(traderID);
	 //�ñ���ǩ��˽Կǩ��
	 return pSafeSign(uid, pOrgData, nOrgDataSize, pSignData, pSignDataSize);
 }
 int DLLEXPORT verify(char* traderID, unsigned char* sgePubKey, int sgePubKeyLen, unsigned char* pOrgData, int nOrgDataSize, unsigned char* pSignData, int nSignDataSize)
 {
	 printf("callback safe_VerifySign\n");
	 //�ý�����ǩ����Կ��ǩ
	 return pSafeVerifySign(sgePubKey, sgePubKeyLen, pOrgData, nOrgDataSize, pSignData, nSignDataSize);
 }

 //���뵥Ԫ��¼
 int gtpLogin(char* traderid, char* accessid)
 {
	 int ret = 0;
	 BREAK_DATA_INFO breakData;

	 //ѯ����4����Ϣ���ϵ���Ϣ
	 memset(&breakData, 0x00, sizeof(BREAK_DATA_INFO));
	 strcpy(breakData.breakDate, "20170719");
	 breakData.breakInfo[0].csequenceSeriesNo = '3'; //˽����
	 breakData.breakInfo[0].isequenceNo = 0;
	 breakData.breakInfo[1].csequenceSeriesNo = '4'; //������
	 breakData.breakInfo[1].isequenceNo = 0;
	 breakData.breakInfo[2].csequenceSeriesNo = '6'; //������
	 breakData.breakInfo[2].isequenceNo = 0;
	 breakData.breakInfo[3].csequenceSeriesNo = '2'; //�ر���
	 breakData.breakInfo[3].isequenceNo = 0;
	 //��¼
	 ret = pGTPLogin("180.2.31.116,127.0.0.1","9333", traderid, accessid, "abc123", &breakData);
	 if (ret != 0) {
		 printf("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!login fail [%s] ret=[%d]\n", traderid, ret);
		 return ret;
	 }
	printf("login success[%s]\n", traderid);
	//ע����Ϣ���ջص�����
	ret = pGTPMsgRec(traderid, printcallback, printcallErrorback, printcallUTCTimeBack);
	return ret;
}

//����Ա��¼
int traderLogin(char* traderid, char* accessid)
{
	int ret=0;
	HEADER header;
	char ctmpbuf1[2000];
	char *temp = NULL;
	printf("traderLogin started\n");
	char *string1 = NULL;
	unsigned int logID=0;

	memset(ctmpbuf1, 0x00, 2000);

	memset(&header, 0x00, sizeof(HEADER));
	char* pwd = "E99A18C428CB38D5F260853678922E03"; //md5
	string1 = "M60=%s,M62=%s";
	SNPRINTF(ctmpbuf1, 2000, string1, traderid, pwd);
	header.cbeginString = NULL;    //��ѡ����
	header.ccontentLength = NULL;  //��ѡ����
	header.cmsgType = "A400";     //������
	header.csequenceSeriesNo = "1"; //������
	header.csequenceNo = "0"; //������
	header.cchainFlag = "S";   //��ѡ����
	ret = pGTPMsgSend(accessid, &header, ctmpbuf1, &logID);
	if(ret != 0){
		printf("send msg error ret=[%d]\n", ret);
	}else{
		printf("send msg done logID=[%d]\n", logID);
	}
	return ret;
}

//�ֿ���Ϣ��ѯ
int warehouseQuery(char* traderid, char* accessid)
{
	int ret = 0;
	HEADER header;
	char ctmpbuf1[2000];
	char *temp = NULL;
	printf("warehouseQuery started\n");
	char *string1 = NULL;
	unsigned int logID = 0;

	string1 = "T01=%s,R10=%s";
	memset(ctmpbuf1, 0x00, 2000);
	SNPRINTF(ctmpbuf1, 2000, string1, traderid, seatid);

	memset(&header, 0x00, sizeof(HEADER));
	header.cbeginString = NULL;    //��ѡ����
	header.ccontentLength = NULL;  //��ѡ����
	header.cmsgType = "B760";     //������
	header.csequenceSeriesNo = "5"; //������
	header.csequenceNo = "0"; //������
	header.cchainFlag = "S";   //��ѡ����
	ret = pGTPMsgSend(accessid, &header, ctmpbuf1, &logID);
	if (ret != 0) {
		printf("send msg error ret=[%d]\n", ret);
	}
	else {
		printf("send msg done logID=[%d]\n", logID);
	}
	return ret;
}


//����������Ϣ
int regRecv(char* accessid)
{
	int ret = 0;
	HEADER header;
	char ctmpbuf1[2000];
	printf("regRecv started\n");
	char *string1 = NULL;
	unsigned int logID = 0;

	memset(ctmpbuf1, 0x00, 2000);

	memset(&header, 0x00, sizeof(HEADER));

	string1 = "X22=%s";
	SNPRINTF(ctmpbuf1, 2000, string1, accessid);

	header.cbeginString = NULL;    //��ѡ����
	header.ccontentLength = NULL;  //��ѡ����
	header.cmsgType = "A200";     //������
	header.csequenceSeriesNo = "1"; //������
	header.csequenceNo = "0"; //������
	header.cchainFlag = "S";   //��ѡ����
	ret = pGTPMsgSend(accessid, &header, ctmpbuf1, &logID);
	if (ret != 0) {
		printf("send msg error ret=[%d]\n", ret);
	}
	else {
		printf("send msg done logID=[%d]\n", logID);
	}
	return ret;
}

int loaddll()
{
#ifdef _WIN32
	DllHandle = LoadLibrary(TEXT(LIBRARY_FILE_NAME));
	SafeDllHandle = LoadLibrary(TEXT(SAFE_LIBRARY_FILE_NAME));
#else
	DllHandle = dlopen(LIBRARY_FILE_NAME, RTLD_LAZY);
	SafeDllHandle = dlopen(SAFE_LIBRARY_FILE_NAME, RTLD_LAZY);
#endif // _WIN32
	if (DllHandle == NULL)
	{
		printf("loaddll error: %s\n", LIBRARY_FILE_NAME);
		return -1;
	}
	if (SafeDllHandle == NULL)
	{
		printf("loaddll error: %s\n", SAFE_LIBRARY_FILE_NAME);
		return -1;
	}
	if ((pGTPEnvInit = (GTPEnvInitProc)loadfunction(DllHandle, "GTPEnvInit")) == NULL) { printf("load function GTPEnvInit error\n"); return -1; }
	if ((pGTPSetOption = (GTPSetOptionProc)loadfunction(DllHandle, "GTPSetOption")) == NULL) { printf("load function GTPSetOption error\n"); return -1; }
	if ((pGTPLogin = (GTPLoginProc)loadfunction(DllHandle, "GTPLogin")) == NULL) { printf("load function GTPLogin error\n"); return -1; }
	if ((pGTPLogout = (GTPLogoutProc)loadfunction(DllHandle, "GTPLogout")) == NULL) { printf("load function GTPLogout error\n"); return -1; }
	if ((pGTPMsgRec = (GTPMsgRecProc)loadfunction(DllHandle, "GTPMsgRec")) == NULL) { printf("load function GTPMsgRec error\n"); return -1; }
	if ((pGTPMsgSend = (GTPMsgSendProc)loadfunction(DllHandle, "GTPMsgSend")) == NULL) { printf("load function GTPMsgSend error\n"); return -1; }
	if ((pGTPEnvClear = (GTPEnvClearProc)loadfunction(DllHandle, "GTPEnvClear")) == NULL) { printf("load function GTPEnvClear error\n"); return -1; }
	
	if ((pSafeInitEnv = (InitEnvProc)loadfunction(SafeDllHandle, "InitEnv")) == NULL) { printf("load function InitEnv error\n"); return -1; }
	if ((pSafeClearEnv = (ClearEnvProc)loadfunction(SafeDllHandle, "ClearEnv")) == NULL) { printf("load function ClearEnv error\n"); return -1; }
	if ((pSafeConfirmSessionKey = (ConfirmSessionKeyProc)loadfunction(SafeDllHandle, "ConfirmSessionKey")) == NULL) { printf("load function ConfirmSessionKey error\n"); return -1; }
	if ((pSafeSign = (SignProc)loadfunction(SafeDllHandle, "Sign")) == NULL) { printf("load function Sign error\n"); return -1; }
	if ((pSafeVerifySign = (VerifySignProc)loadfunction(SafeDllHandle, "VerifySign")) == NULL) { printf("load function VerifySign error\n"); return -1; }
	if ((pSafeGetPubKeyForSign = (GetPubKeyForSignProc)loadfunction(SafeDllHandle, "GetPubKeyForSign")) == NULL) { printf("load function GetPubKeyForSign error\n"); return -1; }
	if ((pSafeGetPubKey = (GetPubKeyProc)loadfunction(SafeDllHandle, "GetPubKey")) == NULL) { printf("load function GetPubKey error\n"); return -1; }
	if ((pSafeSM4Encrypt = (SM4EncryptProc)loadfunction(SafeDllHandle, "SM4Encrypt")) == NULL) { printf("load function SM4Encrypt error\n"); return -1; }
	if ((pSafeSM4Decrypt = (SM4DecryptProc)loadfunction(SafeDllHandle, "SM4Decrypt")) == NULL) { printf("load function SM4Decrypt error\n"); return -1; }

	return 0;
}

//GTPAPI.dll����main
int main(int argc, const char * const * argv, const char * const*env)
{
	int ret = 0;
	int i = 0;
	unsigned int logID = 0;

	printf("test start\n");

	ret = loaddll();
	if (ret != 0)
	{
		printf("load dll error [%d]\n", ret);
		return -1;
	}

	//��ʼ������
	safe_func.init = init;
	safe_func.clear = clear;
	safe_func.getPubKey = getpubkey;
	safe_func.sign = sign;
	safe_func.verify = verify;
	safe_func.confirmkey = confirmkey;
	safe_func.encrypt = encrypt;
	safe_func.decrypt = decrypt;
	ret = pGTPEnvInit(&safe_func);
	if (ret != 0) {
		printf("init error [%d]\n", ret);
		return 0;
	}

	const static int count = 2;

	ret = gtpLogin(traderid[0], accessid);
	if (ret != 0)
	{
		printf("login failed, press Enter to quit\n");
		SCANF("*");
		return -1;
	}
	regRecv(accessid);

#ifdef _WIN32
	HANDLE handlers[count];
	for (i = 0; i < count; i++)
	{
		handlers[i] = CreateThread(NULL, 0, ThreadFun, (void*)traderid[i], 0, NULL);
	}
	DWORD dw = WaitForMultipleObjects(count, handlers, TRUE, 30000);
#else
	pthread_t tid[count];
	for (i = 0; i < count; i++)
	{
		if (pthread_create(&tid[i], NULL, ThreadFun, (void*)traderid[i]) == -1)
			printf("create thread error:");
	}
	for (i = 0; i < count; i++)
	{
		pthread_join(tid[i], NULL);
	}
#endif
	SLEEP(30);
	//�ǳ����뵥Ԫ
	ret = pGTPLogout(accessid);
	printf("[%s] logout done...\n", accessid);
    return 0;
}
