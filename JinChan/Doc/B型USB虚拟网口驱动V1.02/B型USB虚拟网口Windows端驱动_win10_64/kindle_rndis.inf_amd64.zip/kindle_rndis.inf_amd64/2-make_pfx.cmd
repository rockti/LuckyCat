:: you will find pvk2pfx.exe in the Enterprise WDK
::https://msdn.microsoft.com/en-us/windows/hardware/drivers/develop/installing-the-enterprise-wdk
:: correct the C:\EWDK path below if needed

:: use -po <newpassword> to set a different password
"C:\EWDK\Program Files\Windows Kits\10\bin\x86\pvk2pfx.exe" ^
  -pvk MobileRead-CodeSigning-CA.pvk -spc MobileRead-CodeSigning-CA.cer ^
  -f -pfx MobileRead-CodeSigning-CA.pfx
