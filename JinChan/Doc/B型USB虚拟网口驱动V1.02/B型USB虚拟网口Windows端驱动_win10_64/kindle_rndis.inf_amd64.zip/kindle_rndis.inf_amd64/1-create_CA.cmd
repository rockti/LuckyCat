:: you will find makecert.exe in the Enterprise WDK
::https://msdn.microsoft.com/en-us/windows/hardware/drivers/develop/installing-the-enterprise-wdk
:: correct the C:\EWDK path below if needed

:: for help: makecert /? and makecert /!

"C:\EWDK\Program Files\Windows Kits\10\bin\x86\makecert.exe" ^
  -r -pe -n "CN=MobileRead-CodeSigning-CA,O=MobileRead Forums,OU=Marco77" -ss My -sr CurrentUser ^
  -a sha256 -cy end -sky signature -sv MobileRead-CodeSigning-CA.pvk -eku 1.3.6.1.5.5.7.3.3 -len 2048 ^
  MobileRead-CodeSigning-CA.cer
