:: you will find inf2cat.exe in the Enterprise WDK
::https://msdn.microsoft.com/en-us/windows/hardware/drivers/develop/installing-the-enterprise-wdk
:: correct the C:\EWDK path below if needed

::Note: the command below will use the CatalogFile.NTAMD64
::      line in .INF to determine the output filename.
"C:\EWDK\Program Files\Windows Kits\10\bin\x86\Inf2Cat.exe" /driver:. /os:8_X64 /v
