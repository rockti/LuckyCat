:: you will find signtool.exe in the Enterprise WDK
::https://msdn.microsoft.com/en-us/windows/hardware/drivers/develop/installing-the-enterprise-wdk
:: correct the C:\EWDK path below if needed

"C:\EWDK\Program Files\Windows Kits\10\bin\x86\signtool.exe" sign /v ^
  /f MobileRead-CodeSigning-CA.pfx ^
  /fd sha256 /tr http://timestamp.comodoca.com/?td=sha256 /td sha256 ^
  kindle_rndisamd64.cat
