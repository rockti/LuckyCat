::run as admin

cd /d %~dp0

call %SYSTEMROOT%\System32\certutil.exe -f -addstore "Root" MobileRead-CodeSigning-CA.cer

call %SYSTEMROOT%\System32\certutil.exe -f -addstore "TrustedPublisher" MobileRead-CodeSigning-CA.cer

pause