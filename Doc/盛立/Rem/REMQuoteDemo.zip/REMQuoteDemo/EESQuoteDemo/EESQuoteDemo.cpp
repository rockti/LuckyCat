#include "EESQuoteDemo.h"
#include <iostream>
using std::cout;
using std::cin;
using std::endl;

QuoteDemo::QuoteDemo(void)
{
	m_eesApi = NULL;
	m_handle = NULL;

}


QuoteDemo::~QuoteDemo(void)
{
}

void QuoteDemo::Run()
{
	InputParam();

	bool ret = Init();
	if (!ret)
	{
		Pause();
		return;
	}
	Pause();
	Close();
}

bool QuoteDemo::Init()
{
	bool ret = LoadEESQuote();
	if (!ret)
	{
		return false;
	}

	EqsTcpInfo			info;
	vector<EqsTcpInfo>	vec_info;

	memset(&info, 0, sizeof(EqsTcpInfo));
	strcpy(info.m_eqsIp, m_quoteServerIp.c_str());
	info.m_eqsPort = m_quotePort;
	vec_info.push_back(info);

	ret = m_eesApi->ConnServer(vec_info, this);
	if (!ret)
	{
		printf("Connect Quote Server Failed!\n");
		return false;
	}
	else
	{
		printf("Connect Quote Server OK!\n");
	}

	return true;
}

void QuoteDemo::Close()
{
	if (m_eesApi)
	{
		m_eesApi->DisConnServer();
	}

	UnloadEESQuote();
}


void QuoteDemo::Pause()
{
	string str_temp;

	printf("\nPress any key to continue:\n");
	cin >> str_temp;
}


void QuoteDemo::OnEqsConnected()
{
	Logon();
}

void QuoteDemo::OnEqsDisconnected()
{
	printf("Eqs Disconnected.\n");
}

void QuoteDemo::OnLoginResponse(bool bSuccess, const char* pReason)
{
	if (!bSuccess)
	{
		printf("Login Quote Server Failed: %s!\n",pReason);
		return;
	}

	printf("Login Quote Server OK!\n");

	QueryAllSymbol();
}

void QuoteDemo::OnQuoteUpdated(EesEqsIntrumentType chInstrumentType, EESMarketDepthQuoteData* pDepthQuoteData)
{
	ShowQuote(pDepthQuoteData);
}


void QuoteDemo::OnSymbolRegisterResponse(EesEqsIntrumentType chInstrumentType, const char* pSymbol, bool bSuccess)
{
	if (bSuccess)
	{
		printf("Symbol(%s) Registered.\n", pSymbol);
	}
	else
	{
		printf("Symbol(%s) Register Failed.\n", pSymbol);
	}
	
}

void QuoteDemo::OnSymbolUnregisterResponse(EesEqsIntrumentType chInstrumentType, const char* pSymbol, bool bSuccess)
{
	if (bSuccess)
	{
		printf("Symbol(%s) Unregistered.\n", pSymbol);
	}
	else
	{
		printf("Symbol(%s) Unregister Failed.\n", pSymbol);
	}
}

void QuoteDemo::OnSymbolListResponse(EesEqsIntrumentType chInstrumentType, const char* pSymbol, bool bLast)
{
	string strSymbol = pSymbol;
	if (!strSymbol.empty())
	{
		printf("Symbol:	%s\n", pSymbol);

		RegisterSymbol(chInstrumentType, pSymbol);
	}

	if (bLast)
	{
		printf("\nSymbo List finished, enter any char to quit:\n");
	}
}

bool QuoteDemo::LoadEESQuote()
{
#ifdef WIN32
	
	return Windows_LoadEESQuote();

#else
	
	return Linux_LoadEESQuote();

#endif
}

void QuoteDemo::UnloadEESQuote()
{
#ifdef WIN32

	return Windows_UnloadEESQuote();

#else

	return Linux_UnloadEESQuote();

#endif
}

bool QuoteDemo::Windows_LoadEESQuote()
{
#ifdef WIN32

	m_handle =  LoadLibrary(EES_QUOTE_DLL_NAME);
	if (!m_handle)
	{
		printf("Load (%s) Failed.\n", EES_QUOTE_DLL_NAME);
		return false;
	}

	funcCreateEESQuoteApi createFun = (funcCreateEESQuoteApi)GetProcAddress(m_handle, CREATE_EES_QUOTE_API_NAME);
	if (!createFun)
	{
		printf("GetProcAddress (%s) Failed!\n", CREATE_EES_QUOTE_API_NAME);
		return false;
	}

	m_distoryFun = (funcDestroyEESQuoteApi)GetProcAddress(m_handle, DESTROY_EES_QUOTE_API_NAME);
	if (!createFun)
	{
		printf("GetProcAddress (%s) Failed!\n", DESTROY_EES_QUOTE_API_NAME);
		return false;
	}

	m_eesApi = createFun();
	if (!m_eesApi)
	{
		printf("Create Quote Api Instance Failed!\n");
		return false;
	}

#endif

	return true;
}
void QuoteDemo::Windows_UnloadEESQuote()
{
#ifdef WIN32
	if (m_eesApi)
	{
		m_distoryFun(m_eesApi);
		m_eesApi = NULL;
		m_distoryFun = NULL;
	}

	if (m_handle)
	{
		FreeLibrary(m_handle);
		m_handle = NULL;
	}
#endif
}

bool QuoteDemo::Linux_LoadEESQuote()
{
#ifndef WIN32
	m_handle =  dlopen(EES_QUOTE_DLL_NAME, RTLD_LAZY);
	if (!m_handle)
	{
		printf("����EES���鶯̬��(%s)ʧ��\n", EES_QUOTE_DLL_NAME);
		return false;
	}

	funcCreateEESQuoteApi createFun = (funcCreateEESQuoteApi)dlsym(m_handle, CREATE_EES_QUOTE_API_NAME);
	if (!createFun)
	{
		printf("��ȡEES����������ַʧ��!\n");
		return false;
	}

	m_distoryFun = (funcDestroyEESQuoteApi)dlsym(m_handle, DESTROY_EES_QUOTE_API_NAME);
	if (!createFun)
	{
		printf("��ȡEES���ٺ�����ַʧ��!\n");
		return false;
	}

	m_eesApi = createFun();
	if (!m_eesApi)
	{
		printf("����EES�������ʧ��!\n");
		return false;
	}

#endif

	return true;
}

void QuoteDemo::Linux_UnloadEESQuote()
{
#ifndef WIN32
	if (m_eesApi)
	{
		m_distoryFun(m_eesApi);
		m_eesApi = NULL;
		m_distoryFun = NULL;
	}

	if (m_handle)
	{
		dlclose(m_handle);
		m_handle = NULL;
	}
#endif
}


void QuoteDemo::InputParam()
{
	m_quoteServerIp = "183.129.220.106";
	m_quotePort = 20006;
	m_logonId = "test1";
	m_logonPwd = "1";



	cout << "m_quoteServerIp: " << m_quoteServerIp << endl;
	cout << "m_quotePort    : " << m_quotePort << endl;
	cout << "m_logonId      : " << m_logonId << endl;
	cout << "m_logonPwd     : " << m_logonPwd << endl;

}

void QuoteDemo::Logon()
{
	EqsLoginParam temp;

	strcpy(temp.m_loginId, m_logonId.c_str());
	strcpy(temp.m_password, m_logonPwd.c_str());

	if (!m_eesApi)
	{
		printf("Invalid Quote Api Instance\n");
		return;
	}

	m_eesApi->LoginToEqs(temp);
}

void QuoteDemo::QueryAllSymbol()
{
	if (!m_eesApi)
	{
		printf("Invalid Quote Api Instance\n");
		return;
	}

	m_eesApi->QuerySymbolList();
}

void QuoteDemo::RegisterSymbol(EesEqsIntrumentType chInstrumentType, const char* pSymbol)
{
	if (!m_eesApi)
	{
		printf("Invalid Quote Api Instance\n");
		return;
	}

	m_eesApi->RegisterSymbol(chInstrumentType, pSymbol);
}


void QuoteDemo::ShowQuote(EESMarketDepthQuoteData* pQuote)
{
	printf("------------------------------\n");
	printf("Symbol:     %s\n", pQuote->InstrumentID);
	printf("LastPrice:  %.4f\n", pQuote->LastPrice);
	printf("Volume:     %d\n", pQuote->Volume);
	printf("Bid:        %.4f\n", pQuote->BidPrice1);
	printf("Ask:        %.4f\n", pQuote->AskPrice1);
	printf("\n");
}

